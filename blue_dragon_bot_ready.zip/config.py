BOT_TOKEN = "8410974753:AAGSem6eMCcA8Z3rzGMWiLjhpZR_9UEqgNU"

BOT_NAME = "蓝龙"

# 老板ID（用户名，仅用于标识）
OWNER_USERNAME = "@kkkRRRRR"

DEFAULT_PRICE = 7.8
DEFAULT_FEE = 5
DEFAULT_CURRENCY = "U"

PERSONA_LINES = [
    "账记清楚，路才走得远。",
    "慢一点没事，别乱。",
    "今天不一定赢，但账一定要清。",
    "蓝龙在，稳住。",
    "别急，盘在，人还在。"
]

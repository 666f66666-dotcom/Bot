import sqlite3, time

conn = sqlite3.connect("data.db", check_same_thread=False)
cur = conn.cursor()

cur.execute("""
CREATE TABLE IF NOT EXISTS groups (
    group_id INTEGER PRIMARY KEY,
    price REAL,
    fee REAL,
    default_currency TEXT
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS operators (
    group_id INTEGER,
    user_id INTEGER
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id INTEGER,
    user_id INTEGER,
    amount REAL,
    price REAL,
    fee REAL,
    currency TEXT,
    note TEXT,
    ts INTEGER
)
""")

conn.commit()

def init_group(gid, price, fee, curcy):
    cur.execute(
        "INSERT OR IGNORE INTO groups VALUES (?,?,?,?)",
        (gid, price, fee, curcy)
    )
    conn.commit()

def get_group(gid):
    cur.execute("SELECT price,fee,default_currency FROM groups WHERE group_id=?", (gid,))
    return cur.fetchone()

def set_currency(gid, curcy):
    cur.execute("UPDATE groups SET default_currency=? WHERE group_id=?", (curcy, gid))
    conn.commit()

def is_op(gid, uid):
    cur.execute("SELECT 1 FROM operators WHERE group_id=? AND user_id=?", (gid, uid))
    return cur.fetchone() is not None

def add_op(gid, uid):
    cur.execute("INSERT INTO operators VALUES (?,?)", (gid, uid))
    conn.commit()

def del_op(gid, uid):
    cur.execute("DELETE FROM operators WHERE group_id=? AND user_id=?", (gid, uid))
    conn.commit()

def list_op(gid):
    cur.execute("SELECT user_id FROM operators WHERE group_id=?", (gid,))
    return [i[0] for i in cur.fetchall()]

def add_record(gid, uid, amt, price, fee, curcy, note):
    cur.execute(
        "INSERT INTO records VALUES (NULL,?,?,?,?,?,?,?,?)",
        (gid, uid, amt, price, fee, curcy, note, int(time.time()))
    )
    conn.commit()

def last_record(gid, amt):
    cur.execute(
        "SELECT id,ts FROM records WHERE group_id=? AND amount=? ORDER BY id DESC LIMIT 1",
        (gid, amt)
    )
    return cur.fetchone()

def delete_record(rid):
    cur.execute("DELETE FROM records WHERE id=?", (rid,))
    conn.commit()

def sum_by_currency(gid, since=0):
    cur.execute("""
        SELECT currency, IFNULL(SUM(amount),0)
        FROM records
        WHERE group_id=? AND ts>?
        GROUP BY currency
    """, (gid, since))
    return cur.fetchall()

import re, time, random
from aiogram import Bot, Dispatcher, executor, types
import db, config

bot = Bot(token=config.BOT_TOKEN)
dp = Dispatcher(bot)

def is_admin(msg):
    return msg.from_user.id in [a.user.id for a in msg.chat.get_administrators()]

def can_op(msg):
    return is_admin(msg) or db.is_op(msg.chat.id, msg.from_user.id)

def dragon_say():
    return random.choice(config.PERSONA_LINES) if random.random() < 0.15 else ""

@dp.message_handler(content_types=types.ContentType.NEW_CHAT_MEMBERS)
async def welcome(msg):
    db.init_group(
        msg.chat.id,
        config.DEFAULT_PRICE,
        config.DEFAULT_FEE,
        config.DEFAULT_CURRENCY
    )
    await msg.reply(
        f"{config.BOT_NAME}在。\n"
        "示例：+100 | +100U | +1000U/7.3 张三\n"
        "查询：总 / 今日总"
    )

@dp.message_handler(lambda m: m.text == "新增操作员")
async def addop(msg):
    if not is_admin(msg) or not msg.reply_to_message:
        return
    uid = msg.reply_to_message.from_user.id
    db.add_op(msg.chat.id, uid)
    await msg.reply("已加。" )

@dp.message_handler(lambda m: m.text == "操作员列表")
async def oplist(msg):
    ops = db.list_op(msg.chat.id)
    await msg.reply("操作员：\n" + "\n".join(map(str, ops)) if ops else "还没人。" )

@dp.message_handler(regexp=r"^删除操作员 \\d+")
async def delop(msg):
    if not is_admin(msg): return
    uid = int(msg.text.split()[-1])
    db.del_op(msg.chat.id, uid)
    await msg.reply("已删。" )

@dp.message_handler(regexp=r"^设置币种")
async def set_cur(msg):
    if not is_admin(msg): return
    c = msg.text.split()[-1].upper()
    db.set_currency(msg.chat.id, c)
    await msg.reply(f"默认币种改成 {c}" )

@dp.message_handler(regexp=r"^[+-]\\d")
async def account(msg):
    if not can_op(msg): return

    price_cfg, fee_rate, def_cur = db.get_group(msg.chat.id)

    m = re.match(
        r"([+-])(\\d+)([A-Za-z]{0,5})?(?:/([\\d.]+))?\\s*(.*)",
        msg.text
    )
    if not m:
        return

    sign, num, curcy, price, note = m.groups()
    num = float(num)
    currency = curcy.upper() if curcy else def_cur
    price = float(price) if price else price_cfg

    amount = num * price if currency == "U" else num
    if sign == "-":
        amount = -amount

    fee = abs(amount) * fee_rate / 100
    real = amount - fee if amount > 0 else amount + fee

    db.add_record(
        msg.chat.id,
        msg.from_user.id,
        real,
        price,
        fee,
        currency,
        note or ""
    )

    await msg.reply(f"✔ 已记\\n{currency} {real}\\n{dragon_say()}" )

@dp.message_handler(regexp=r"^&&")
async def fastdel(msg):
    if not can_op(msg): return
    amt = float(msg.text[2:])
    r = db.last_record(msg.chat.id, amt)
    if not r:
        return await msg.reply("没找到。" )
    rid, ts = r
    if time.time() - ts > 300:
        return await msg.reply("过了5分钟。" )
    db.delete_record(rid)
    await msg.reply("删了。" )

@dp.message_handler(lambda m: m.text == "总")
async def total(msg):
    rows = db.sum_by_currency(msg.chat.id)
    text = "📊 蓝龙账本\\n"
    for c, a in rows:
        text += f"{c}：{a}\\n"
    await msg.reply(text)

@dp.message_handler(lambda m: m.text == "今日总")
async def today(msg):
    rows = db.sum_by_currency(msg.chat.id, int(time.time()) - 86400)
    text = "📅 今日\\n"
    for c, a in rows:
        text += f"{c}：{a}\\n"
    await msg.reply(text)

if __name__ == "__main__":
    executor.start_polling(dp)
